arq = open("clean_position.txt", "r")
file = arq.read()
print(file)
